"""Draw the middle panel of Figure 2 (AR-RF simulated emissions) from the replication workbook."""

import logging
from pathlib import Path

import matplotlib
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parent
WORKBOOK = ROOT / "data" / "replication_data.xlsx"
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)

wb = load_workbook(WORKBOOK, data_only=True)

# Annual quantiles: columns A-G, header in row 5, data from row 6
rows = [r[:7] for r in wb["Annual_quantiles"].iter_rows(min_row=6, values_only=True) if r[0]]
q = pd.DataFrame(rows, columns=["Method", "Scenario", "Pathway", "Year", "Median", "P05", "P95"])
t = q[(q.Method == "Gaussian (primary)") & (q.Scenario == "AR") & (q.Pathway == "RF")].sort_values("Year")

# 90% benchmark threshold from the named range
((sheet, ref),) = wb.defined_names["Threshold_90"].destinations
threshold_90 = float(wb[sheet][ref.replace("$", "")].value)

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)

fig, ax = plt.subplots(figsize=(2.7, 2.55))
ax.fill_between(t.Year, t.P05, t.P95, color="#4A78A8", alpha=0.22, lw=0,
                label="P05–P95 (10,000 runs)")
ax.plot(t.Year, t.Median, color="#2F5D8A", lw=1.8, label="Median")
ax.axhline(threshold_90, color="#1F6F43", ls="--", lw=0.9)
ax.text(2025, threshold_90 + 0.25, "90% benchmark", fontsize=6.6, color="#1F6F43")

ax.set_xlim(2024, 2050)
ax.set_ylim(0, None)
ax.set_xticks([2025, 2030, 2040, 2050])
ax.set_xlabel("Financial-year ending", fontsize=7.5)
ax.set_ylabel("Emissions (Mt CO₂)", fontsize=7.5)
ax.tick_params(labelsize=7, length=2.5)
ax.set_title("Illustration: AR–RF, simulated", fontsize=7.8, loc="left", color="#263238")
ax.legend(frameon=False, fontsize=6.4, loc="upper right")
ax.grid(color="#D8DDE1", lw=0.5, alpha=0.6)
fig.tight_layout(pad=0.3)

for ext, kw in [("png", {"dpi": 600}), ("svg", {}), ("pdf", {})]:
    fig.savefig(OUT / f"Figure_02_middle_panel.{ext}", facecolor="white", **kw)
plt.close(fig)
print(f"Figure 2 middle panel written to {OUT}")
