"""Draw the 2050 cumulative-probability panel for Figure 2 (AR-RF) from the replication workbook.

Under the Gaussian baseline, ln E2050 ~ N(ln E*2050, s2050^2) (manuscript Section 2.3.3),
so the curve is the analytical lognormal CDF. The simulated attainment probability from
Results_2050 is shown alongside the analytical value for comparison.
"""

import logging
import math
from pathlib import Path

import matplotlib
logging.getLogger("matplotlib.font_manager").setLevel(logging.ERROR)
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from openpyxl import load_workbook
from scipy import stats

ROOT = Path(__file__).resolve().parent
WORKBOOK = ROOT / "data" / "replication_data.xlsx"
OUT = ROOT / "figures"
OUT.mkdir(exist_ok=True)

wb = load_workbook(WORKBOOK, data_only=True)


def named(name: str) -> float:
    ((sheet, ref),) = wb.defined_names[name].destinations
    return float(wb[sheet][ref.replace("$", "")].value)


threshold_90 = named("Threshold_90")
s_2050 = named("s_2050")
e_star = 0.001 * named("Energy_2050_AR") * named("f_RF_2050")  # deterministic AR-RF 2050, Mt CO2

# Simulated attainment from Results_2050 (Gaussian primary, AR, RF)
p_sim = None
for row in wb["Results_2050"].iter_rows(min_row=6, values_only=True):
    if row[0] == "Gaussian (primary)" and row[1] == "AR" and row[2] == "RF":
        p_sim = float(row[8])  # P(>=90% reduction)
        break
p_analytic = stats.norm.cdf(math.log(threshold_90 / e_star) / s_2050)

x = np.linspace(0.05, 4.0, 600)
cdf = stats.norm.cdf(np.log(x / e_star) / s_2050)

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
    }
)

fig, ax = plt.subplots(figsize=(2.7, 2.55))
ax.plot(x, cdf, color="#2F5D8A", lw=1.8)
mask = x <= threshold_90
ax.fill_between(x[mask], 0, cdf[mask], color="#3F9D58", alpha=0.25, lw=0)
ax.axvline(threshold_90, color="#1F6F43", ls="--", lw=0.9)
ax.axhline(p_analytic, xmax=(threshold_90 - 0) / 4.0, color="#1F6F43", ls=":", lw=0.8)
ax.text(threshold_90 + 0.08, 0.06, "90% benchmark\n(0.897 Mt)", fontsize=6.4, color="#1F6F43", va="bottom")
ax.annotate(
    f"P(E₂₀₅₀ ≤ benchmark)\n= {p_sim:.1%} simulated\n({p_analytic:.1%} analytical)",
    xy=(threshold_90, p_analytic), xytext=(1.55, 0.42), fontsize=6.4, color="#263238",
    arrowprops=dict(arrowstyle="-", color="#7B848C", lw=0.7),
)

ax.set_xlim(0, 4.0)
ax.set_ylim(0, 1.02)
ax.set_xlabel("2050 emissions (Mt CO₂)", fontsize=7.5)
ax.set_ylabel("Cumulative probability", fontsize=7.5)
ax.tick_params(labelsize=7, length=2.5)
ax.set_title("Illustration: AR–RF, 2050", fontsize=7.8, loc="left", color="#263238")
ax.grid(color="#D8DDE1", lw=0.5, alpha=0.6)
fig.tight_layout(pad=0.3)

for ext, kw in [("png", {"dpi": 600}), ("svg", {}), ("pdf", {})]:
    fig.savefig(OUT / f"Figure_02_cdf_panel.{ext}", facecolor="white", **kw)
plt.close(fig)
print(f"Figure 2 CDF panel written to {OUT}  (simulated {p_sim:.1%}, analytical {p_analytic:.1%})")
