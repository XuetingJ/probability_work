"""Reproduce manuscript Figures 3–9 from stored model outputs.

The script reads the replication workbook and does not rerun the Monte Carlo model.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from io import BytesIO
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from openpyxl import load_workbook
from scipy import stats


ROOT = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(
    description=(
        "Reproduce manuscript Figures 3–9 from the replication workbook."
    )
)
parser.add_argument(
    "--lock",
    type=Path,
    default=ROOT / "data" / "replication_data.xlsx",
)
parser.add_argument(
    "--output",
    type=Path,
    default=ROOT / "figures",
)
args = parser.parse_args()

LOCK = args.lock.resolve()
OUT = args.output.resolve()
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 9.2,
        "axes.titlesize": 10.2,
        "axes.labelsize": 9.2,
        "legend.fontsize": 8.2,
        "xtick.labelsize": 8.2,
        "ytick.labelsize": 8.2,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "axes.linewidth": 0.75,
        "axes.titleweight": "semibold",
        "axes.axisbelow": True,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "svg.fonttype": "none",
        "svg.hashsalt": "aviation-reliability-figures",
        "savefig.facecolor": "white",
        "figure.facecolor": "white",
    }
)

SCENARIOS = ["BAU", "IP", "AR"]
PATHS = ["CI", "RF", "NZ"]
PANEL_LETTERS = "abcdefghijklmnopqrstuvwxyz"


wb = load_workbook(LOCK, data_only=True)

PRIMARY = "Gaussian (primary)"
BOOT3 = "Block bootstrap, L = 3"
BOOT5 = "Block bootstrap, L = 5"


def read_table(sheet: str, columns: list[str], header_row: int = 5) -> pd.DataFrame:
    """Read a contiguous table that starts under `header_row` and ends at the first blank row."""
    rows = []
    for row in wb[sheet].iter_rows(min_row=header_row + 1, values_only=True):
        if row[0] is None:
            break
        rows.append(row[: len(columns)])
    return pd.DataFrame(rows, columns=columns)


def named(name: str) -> float:
    """Value of a workbook-level named range (e.g. Threshold_90)."""
    ((sheet, ref),) = wb.defined_names[name].destinations
    return float(wb[sheet][ref.replace("$", "")].value)


results = read_table(
    "Results_2050",
    ["Method", "Scenario", "Pathway", "N", "median", "p05", "p95", "p80", "p90", "p95bench", "cum_median"],
)
primary = results[results.Method == PRIMARY].copy()

paths = read_table(
    "Paths",
    ["Scenario", "Year", "D_billion_tkme", "e_MJ_tkme", "Energy_PJ", "mean_log_D", "mean_log_e",
     "f_CI", "f_RF", "f_NZ", "E_CI", "E_RF", "E_NZ"],
)
det = pd.concat(
    [
        paths[["Scenario", "Year", "D_billion_tkme", "e_MJ_tkme", "mean_log_D", "mean_log_e"]].assign(
            Pathway=p, f_gCO2_MJ=paths[f"f_{p}"], E_Mt=paths[f"E_{p}"]
        )
        for p in PATHS
    ],
    ignore_index=True,
)[["Scenario", "Pathway", "Year", "D_billion_tkme", "e_MJ_tkme", "f_gCO2_MJ", "E_Mt", "mean_log_D", "mean_log_e"]]

ann = read_table("Annual_quantiles", ["Method", "Scenario", "Pathway", "Year", "Median", "P05", "P95"])
ann = ann[ann.Method == PRIMARY].copy()

assert len(primary) == 9
assert len(det) == 243
assert len(ann) == 243
assert np.allclose(
    det.E_Mt,
    det.D_billion_tkme * det.e_MJ_tkme * det.f_gCO2_MJ / 1000,
    rtol=1e-12,
    atol=1e-12,
)

benchmark_2019 = named("Emissions_2019")
anchor_2024 = named("Emissions_2024")
anchor_e_2024 = named("Intensity_2024")
anchor_f_2024 = named("CarbonFactor_2024")
thresholds = {
    "80%": named("Threshold_80"),
    "90%": named("Threshold_90"),
    "95%": named("Threshold_95"),
}
rf_2050 = named("f_RF_2050")

sigma_D = named("sigma_D")
sigma_e = named("sigma_e")
rho = named("rho")
cov = named("cov_De")
sigma1_sq = sigma_D**2 + sigma_e**2 + 2 * cov
sigma_26 = math.sqrt(26 * sigma1_sq)
assert math.isclose(sigma_26, named("s_2050"), rel_tol=1e-12)

energy_2050 = {scenario: named(f"Energy_2050_{scenario}") for scenario in SCENARIOS}

reliabilities = [0.50, 0.66, 0.90]
requirement_rows = []
for scenario in SCENARIOS:
    for q in reliabilities:
        f_req = (
            0.10
            * benchmark_2019
            * math.exp(-stats.norm.ppf(q) * sigma_26)
            / (0.001 * energy_2050[scenario])
        )
        requirement_rows.append({"Scenario": scenario, "Reliability": q, "f_required": f_req})
requirements = pd.DataFrame(requirement_rows)

expected_rounded = {
    ("BAU", 0.50): 3.1,
    ("BAU", 0.66): 2.6,
    ("BAU", 0.90): 1.8,
    ("IP", 0.50): 5.3,
    ("IP", 0.66): 4.4,
    ("IP", 0.90): 3.0,
    ("AR", 0.50): 15.0,
    ("AR", 0.66): 12.5,
    ("AR", 0.90): 8.5,
}
for row in requirements.itertuples():
    assert round(row.f_required, 1) == expected_rounded[(row.Scenario, row.Reliability)]

# Export source tables.
data_out = OUT / "figure_data"
data_out.mkdir(exist_ok=True)
primary.to_csv(data_out / "primary_results.csv", index=False)
results.to_csv(data_out / "stochastic_results.csv", index=False)
det.to_csv(data_out / "deterministic_paths.csv", index=False)
ann.to_csv(data_out / "annual_quantiles.csv", index=False)
requirements.to_csv(data_out / "required_carbon_intensity_90pct_benchmark.csv", index=False)

manifest: list[dict] = []


def save(fig, number: int, label: str) -> None:
    base = f"Figure_{number:02d}_{label}"
    pdf = BytesIO()
    fig.savefig(
        pdf,
        format="pdf",
        bbox_inches="tight",
        pad_inches=0.08,
        metadata={"CreationDate": None, "ModDate": None},
    )
    (OUT / f"{base}.pdf").write_bytes(pdf.getvalue())

    svg = BytesIO()
    fig.savefig(
        svg,
        format="svg",
        bbox_inches="tight",
        pad_inches=0.08,
        metadata={"Date": None},
    )
    (OUT / f"{base}.svg").write_bytes(svg.getvalue())

    png = BytesIO()
    fig.savefig(
        png,
        format="png",
        dpi=600,
        bbox_inches="tight",
        pad_inches=0.08,
        facecolor="white",
    )
    (OUT / f"{base}.png").write_bytes(png.getvalue())

    manifest.append(
        {
            "figure": number,
            "pdf": f"{base}.pdf",
            "svg": f"{base}.svg",
            "png": f"{base}.png",
            "png_dpi": 600,
        }
    )
    plt.close(fig)


ACCENT_GREEN = "#3F9D58"
DARK_GREEN = "#1F6F43"
PALE_GREEN = "#DDEFD9"
VERY_PALE_GREEN = "#F1F8EF"
GOLD = "#C6912E"
BLUE = "#4A78A8"
RED = "#C94F4F"
MID_GREY = "#9AA3AD"
DARK_GREY = "#3E474F"
LIGHT_GREY = "#E8EBEE"
INK = "#263238"

PATH_COLOURS = {"CI": MID_GREY, "RF": GOLD, "NZ": ACCENT_GREEN}
PATH_STYLES = {"CI": "-", "RF": "--", "NZ": "-."}
SCENARIO_COLOURS = {"BAU": MID_GREY, "IP": GOLD, "AR": ACCENT_GREEN}
SCENARIO_STYLES = {"BAU": "-", "IP": "--", "AR": "-."}


def panel_heading(ax, letter: str, title: str, subtitle: str | None = None) -> None:
    ax.text(0.0, 1.055, letter, transform=ax.transAxes, ha="left", va="bottom",
            fontsize=10.5, fontweight="bold", color=INK)
    ax.text(0.065, 1.055, title, transform=ax.transAxes, ha="left", va="bottom",
            fontsize=9.2, fontweight="semibold", color=INK)
    if subtitle:
        ax.text(0.065, 1.005, subtitle, transform=ax.transAxes, ha="left", va="bottom",
                fontsize=7.1, color="#68727C")


def finish_axis(ax, grid_axis: str = "both") -> None:
    ax.grid(axis=grid_axis, color="#D8DDE1", lw=0.55, alpha=0.62)
    ax.tick_params(length=3, width=0.7, color="#6C747C")
    ax.spines["left"].set_color("#59636D")
    ax.spines["bottom"].set_color("#59636D")


# Figure 3: Pathways
fig, axs = plt.subplots(1, 2, figsize=(7.35, 3.48))
fig.subplots_adjust(left=0.09, right=0.94, bottom=0.17, top=0.76, wspace=0.34)

ax = axs[0]
for scenario in SCENARIOS:
    t = det[(det.Scenario == scenario) & (det.Pathway == "CI")].sort_values("Year")
    ax.plot(t.Year, t.e_MJ_tkme, color=SCENARIO_COLOURS[scenario],
            ls=SCENARIO_STYLES[scenario], lw=2.1)
    end = t.iloc[-1]
    ax.text(2050.6, end.e_MJ_tkme, f"{scenario}  {end.e_MJ_tkme:.1f}",
            ha="left", va="center", fontsize=8.0, color=SCENARIO_COLOURS[scenario],
            fontweight="semibold", clip_on=False)
ax.scatter([2024], [anchor_e_2024], s=24, color=INK, zorder=5)
ax.annotate(f"2024 anchor  {anchor_e_2024:.2f}", (2024, anchor_e_2024),
            xytext=(2030, 21.7), textcoords="data", fontsize=7.2, color=INK,
            arrowprops=dict(arrowstyle="-", color="#7B848C", lw=0.7))
ax.set(xlim=(2023.5, 2054), ylim=(6.5, 22.8), xlabel="Financial-year ending",
       ylabel="Energy intensity (MJ/tkme)")
panel_heading(ax, "a", "Energy intensity", "Lower values indicate stronger energy-productivity improvement.")
finish_axis(ax)

ax = axs[1]
for path in PATHS:
    t = det[(det.Scenario == "BAU") & (det.Pathway == path)].sort_values("Year")
    ax.plot(t.Year, t.f_gCO2_MJ, color=PATH_COLOURS[path], ls=PATH_STYLES[path], lw=2.1)
    end = t.iloc[-1]
    y = float(end.f_gCO2_MJ)
    label_y = y if y > 1 else 1.8
    ax.text(2050.6, label_y, f"{path}  {y:.2f}" if path != "CI" else f"{path}  {y:.1f}",
            ha="left", va="center", fontsize=8.0, color=PATH_COLOURS[path],
            fontweight="semibold", clip_on=False)
ax.scatter([2024], [anchor_f_2024], s=24, color=INK, zorder=5)
ax.set(xlim=(2023.5, 2054), ylim=(0, 76), xlabel="Financial-year ending",
       ylabel="Carbon intensity (g CO₂/MJ)")
panel_heading(ax, "b", "Prescribed carbon intensity", "CI remains fossil-intensive; RF declines; NZ reaches zero by construction.")
finish_axis(ax)

save(fig, 3, "Pathways")


# Figure 4: Deterministic emissions
fig, axs = plt.subplots(1, 3, figsize=(7.55, 3.65), sharex=True, sharey=True)
fig.subplots_adjust(left=0.08, right=0.985, bottom=0.18, top=0.75, wspace=0.19)
ymax = float(det.E_Mt.max()) * 1.08
for idx, (ax, scenario) in enumerate(zip(axs, SCENARIOS)):
    ax.axhspan(0, thresholds["95%"], color=ACCENT_GREEN, alpha=0.16, zorder=0)
    ax.axhspan(thresholds["95%"], thresholds["90%"], color=ACCENT_GREEN, alpha=0.105, zorder=0)
    ax.axhspan(thresholds["90%"], thresholds["80%"], color=ACCENT_GREEN, alpha=0.055, zorder=0)
    for path in PATHS:
        t = det[(det.Scenario == scenario) & (det.Pathway == path)].sort_values("Year")
        ax.plot(t.Year, t.E_Mt, color=PATH_COLOURS[path], ls=PATH_STYLES[path], lw=2.0)
        end = t.iloc[-1]
        ylab = float(end.E_Mt)
        if path == "NZ":
            ylab = 0.20
        if scenario == "AR" and path == "RF":
            ylab = float(end.E_Mt) + 1.0
        ax.text(2050.35, ylab, f"{path}  {float(end.E_Mt):.2f}", fontsize=6.9,
                color=PATH_COLOURS[path], va="center", ha="left", clip_on=False,
                fontweight="semibold" if path == "RF" else "normal")
    ax.scatter([2024], [anchor_2024], s=20, color=INK, zorder=5)
    ax.set(xlim=(2023.5, 2054.3), ylim=(0, ymax), xlabel="Financial-year ending")
    panel_heading(ax, PANEL_LETTERS[idx], scenario)
    finish_axis(ax)
axs[0].set_ylabel("Annual direct CO₂ emissions (Mt CO₂)")
for name, y, alpha in [("80%", thresholds["80%"], 0.7), ("90%", thresholds["90%"], 0.85)]:
    axs[2].axhline(y, color=DARK_GREEN, ls="--" if name == "90%" else ":", lw=0.9, alpha=alpha)
    if name == "80%":
        axs[2].text(2024.4, y + 0.16, f"{name} benchmark", fontsize=6.8, color=DARK_GREEN, va="bottom")
    else:
        axs[2].text(2024.4, y - 0.14, f"{name} benchmark", fontsize=6.8, color=DARK_GREEN, va="top")
ar_rf = det[(det.Scenario == "AR") & (det.Pathway == "RF") & (det.Year == 2050)].iloc[0]
axs[2].annotate(f"AR–RF = {ar_rf.E_Mt:.2f} Mt", (2050, ar_rf.E_Mt),
                xytext=(2036.0, 5.1), fontsize=7.4, color=GOLD, fontweight="semibold",
                bbox=dict(facecolor="white", edgecolor=GOLD, lw=0.6, alpha=0.94, pad=1.8),
                arrowprops=dict(arrowstyle="-", color=GOLD, lw=0.8))

save(fig, 4, "Deterministic_Emissions")


# Figure 5: Probabilistic emissions
fig, axs = plt.subplots(1, 3, figsize=(7.55, 3.70), sharex=True, sharey=True)
fig.subplots_adjust(left=0.08, right=0.985, bottom=0.18, top=0.75, wspace=0.19)
# Common display range; the BAU–CI upper P95 tail is clipped.
ymax = 25.0
for idx, (ax, scenario) in enumerate(zip(axs, SCENARIOS)):
    ax.axhspan(0, thresholds["90%"], color=ACCENT_GREEN, alpha=0.06, zorder=0)
    for path in PATHS:
        t = ann[(ann.Scenario == scenario) & (ann.Pathway == path)].sort_values("Year")
        x=t.Year.to_numpy(float); med=t.Median.to_numpy(float); lo=t.P05.to_numpy(float); hi=t.P95.to_numpy(float)
        ax.fill_between(x, lo, hi, color=PATH_COLOURS[path], alpha=0.10 if path != "RF" else 0.14, linewidth=0)
        ax.plot(x, med, color=PATH_COLOURS[path], ls=PATH_STYLES[path], lw=2.05 if path=="RF" else 1.75)
        end=t.iloc[-1]
        ylab=float(end.Median) if path!="NZ" else 0.20
        if scenario == "AR" and path == "RF":
            ylab = float(end.Median) + 0.45
        ax.text(2050.35, ylab, f"{path}  {float(end.Median):.2f}", fontsize=6.8,
                color=PATH_COLOURS[path], va="center", ha="left", clip_on=False,
                fontweight="semibold" if path=="RF" else "normal")
    ax.scatter([2024],[anchor_2024],s=20,color=INK,zorder=5)
    ax.set(xlim=(2023.5,2054.3),ylim=(0,ymax),xlabel="Financial-year ending")
    panel_heading(ax,PANEL_LETTERS[idx],scenario)
    finish_axis(ax)
axs[0].set_ylabel("Annual direct CO₂ emissions (Mt CO₂)")
axs[2].axhline(thresholds["90%"], color=DARK_GREEN, ls="--", lw=0.9)
axs[2].text(2024.4, thresholds["90%"]+0.22, "90% benchmark", fontsize=6.7, color=DARK_GREEN)

axs[0].text(
    0.97, 0.95,
    "BAU–CI upper P95 tail extends\nbeyond the displayed range",
    transform=axs[0].transAxes,
    ha="right", va="top",
    fontsize=6.7, color="#68727C",
)

save(fig, 5, "Probabilistic_Emissions")


# Figure 6: Endpoint distributions
fig, ax = plt.subplots(figsize=(7.45,4.70))
fig.subplots_adjust(left=0.16,right=0.97,bottom=0.20,top=0.74)
row_order=[("BAU","CI"),("IP","CI"),("AR","CI"),("BAU","RF"),("IP","RF"),("AR","RF")]
ypos=np.arange(len(row_order))[::-1]
ax.axvspan(0.35, thresholds["95%"], color=ACCENT_GREEN, alpha=0.18, zorder=0)
ax.axvspan(thresholds["95%"], thresholds["90%"], color=ACCENT_GREEN, alpha=0.12, zorder=0)
ax.axvspan(thresholds["90%"], thresholds["80%"], color=ACCENT_GREEN, alpha=0.065, zorder=0)
for y,(sc,pa) in zip(ypos,row_order):
    row=primary[(primary.Scenario==sc)&(primary.Pathway==pa)].iloc[0]
    is_focus=(sc,pa)==("AR","RF")
    line_color=GOLD if pa=="RF" else MID_GREY
    ax.hlines(y,row.p05,row.p95,color=line_color,lw=3.0 if is_focus else 1.8,alpha=0.95 if is_focus else 0.72)
    ax.plot(float(row["median"]),y,marker="o",ms=7 if is_focus else 5.5,color=GOLD if is_focus else (GOLD if pa=="RF" else BLUE),
            mec="white",mew=0.8,zorder=3)
    ax.annotate(f"{float(row['median']):.2f}",(float(row["median"]),y),xytext=(0,4),textcoords="offset points",
                ha="center",va="bottom",fontsize=7.8,color=GOLD if is_focus else DARK_GREY,
                fontweight="semibold" if is_focus else "normal",
                bbox=dict(fc="white",ec="none",pad=1,alpha=0.9),zorder=4)
for name,ls in [("95%",":"),("90%","--"),("80%","-.")]:
    x=thresholds[name]; ax.axvline(x,color=DARK_GREEN,ls=ls,lw=0.9)
    ax.text(x,1.025,f"{name}\n{x:.3f}",transform=ax.get_xaxis_transform(),ha="center",va="bottom",
            fontsize=7.0,color=DARK_GREEN)
ax.set_xscale("log");ax.set_xlim(0.35,50);ax.set_ylim(-0.65,5.65)
ax.set_yticks(ypos);ax.set_yticklabels([f"{s}–{p}" for s,p in row_order])
ax.set_xlabel("2050 emissions (Mt CO₂; logarithmic scale)")
ax.axhline(2.5,color="#AAB1B8",lw=0.8)
ax.text(46,5.15,"CI",ha="right",color=BLUE,fontweight="bold",fontsize=8.2)
ax.text(46,2.15,"RF",ha="right",color=GOLD,fontweight="bold",fontsize=8.2)
ax.text(0.99,-0.17,"NZ endpoints equal zero by construction and are omitted from the logarithmic axis.",
        transform=ax.transAxes,ha="right",va="top",fontsize=7.2,color="#5C6670")
finish_axis(ax,"x")

save(fig, 6, "Endpoint_Distributions")


calibration = read_table("Calibration", ["FY", "dlnD", "dlne", "Segment", "resD", "rese"], header_row=20)
assert len(calibration) == 26
gD = calibration.dlnD.to_numpy(float)
ge = calibration.dlne.to_numpy(float)
assert np.isclose(gD.std(ddof=1), sigma_D)
assert np.isclose(ge.std(ddof=1), sigma_e)
assert np.isclose(np.corrcoef(gD, ge)[0, 1], rho)

# Figure 7: Historical diagnostics
fig,axs=plt.subplots(2,2,figsize=(7.45,5.45))
fig.subplots_adjust(left=0.09,right=0.97,bottom=0.12,top=0.78,wspace=0.28,hspace=0.40)
variables=[(gD,"Demand",BLUE),(ge,"Energy intensity",ACCENT_GREEN)]
legend_handles=[]
for j,(vals,name,col) in enumerate(variables):
    ax=axs[0,j]
    ax.hist(vals,bins=8,density=True,color=col,alpha=0.28,edgecolor="white",linewidth=0.7)
    xx=np.linspace(vals.min()-0.03,vals.max()+0.03,300)
    l1,=ax.plot(xx,stats.norm.pdf(xx,vals.mean(),vals.std(ddof=1)),color=DARK_GREY,ls="--",lw=1.35,label="Gaussian reference")
    l2,=ax.plot(xx,stats.gaussian_kde(vals)(xx),color=col,lw=1.8,label="Empirical density")
    if j==0: legend_handles=[l1,l2]
    panel_heading(ax,PANEL_LETTERS[j],f"{name} log changes")
    ax.set(xlabel="Annual log change",ylabel="Density")
    finish_axis(ax)
    ax=axs[1,j]
    (xq,yq),(slope,intercept,_)=stats.probplot(vals,dist="norm")
    ax.scatter(xq,yq,s=20,color=col,edgecolor="white",linewidth=0.4,zorder=3)
    ax.plot(xq,slope*xq+intercept,color=DARK_GREY,ls="--",lw=1.2)
    panel_heading(ax,PANEL_LETTERS[2+j],f"{name} Q–Q plot")
    ax.set(xlabel="Theoretical normal quantile",ylabel="Observed annual log change")
    finish_axis(ax)
fig.legend(handles=legend_handles,loc="upper center",bbox_to_anchor=(0.5,0.865),ncol=2,frameon=False)

save(fig, 7, "Historical_Diagnostics")


# Figure 8: Benchmark attainment and reliability
fig=plt.figure(figsize=(8.65,5.05))
gs=fig.add_gridspec(1,2,width_ratios=[1.12,1.25],left=0.09,right=0.98,bottom=0.16,top=0.72,wspace=0.36)
ax=fig.add_subplot(gs[0,0])
ordered_keys=[(s,p) for s in SCENARIOS for p in PATHS]
op=primary.set_index(["Scenario","Pathway"]).loc[ordered_keys].reset_index()
mat=op[["p80","p90","p95bench"]].to_numpy(float)*100
from matplotlib.colors import LinearSegmentedColormap
cmap=LinearSegmentedColormap.from_list("attain",["#F7FAF6",PALE_GREEN,ACCENT_GREEN,DARK_GREEN])
im=ax.imshow(mat,cmap=cmap,vmin=0,vmax=100,aspect="auto")
ax.set_xticks(range(3));ax.set_xticklabels([f"80%\n≤{thresholds['80%']:.3f}",f"90%\n≤{thresholds['90%']:.3f}",f"95%\n≤{thresholds['95%']:.3f}"],fontsize=7.6)
ax.set_yticks(range(9));ax.set_yticklabels([f"{r.Scenario}–{r.Pathway}"+(" *" if r.Pathway=="NZ" else "") for r in op.itertuples()],fontsize=7.8)
for i in range(9):
    for j in range(3):
        v=mat[i,j];ax.text(j,i,f"{v:.2f}%",ha="center",va="center",fontsize=7.5,
                           color="white" if v>55 else "#1F272E",fontweight="semibold" if i==7 else "normal")
for sep in [2.5,5.5]:ax.axhline(sep,color="#77818A",lw=0.8)
ari=ordered_keys.index(("AR","RF"));ax.add_patch(Rectangle((-0.49,ari-0.49),2.98,0.98,fill=False,edgecolor=GOLD,lw=2.0))
ax.set_xticks(np.arange(-.5,3,1),minor=True);ax.set_yticks(np.arange(-.5,9,1),minor=True);ax.grid(which="minor",color="white",lw=1);ax.tick_params(which="minor",length=0)
panel_heading(ax,"a","Forward test: conditional attainment","Cells report the share of 10,000 outcomes below each fixed benchmark.")
cb=fig.colorbar(im,ax=ax,fraction=.04,pad=.03,shrink=.90);cb.set_label("Attainment probability (%)",fontsize=7.8);cb.ax.tick_params(labelsize=7.2)
ax=fig.add_subplot(gs[0,1])
energy_grid=np.linspace(45,315,500)
line_specs=[(0.50,BLUE,"50% reliability"),(0.66,GOLD,"66% reliability"),(0.90,ACCENT_GREEN,"90% reliability")]
for q,col,label in line_specs:
    fcurve=0.10*benchmark_2019*np.exp(-stats.norm.ppf(q)*sigma_26)/(0.001*energy_grid)
    ax.plot(energy_grid,fcurve,color=col,lw=2.0,label=label)
f90=0.10*benchmark_2019*np.exp(-stats.norm.ppf(.90)*sigma_26)/(0.001*energy_grid)
ax.fill_between(energy_grid,0,f90,color=ACCENT_GREEN,alpha=0.10)
ax.text(48,2.0,"≥90% reliable\nattainment region",fontsize=7.1,color=DARK_GREEN,va="bottom")
ax.axhline(rf_2050,color=GOLD,ls="--",lw=1.2)
ax.text(309,rf_2050+0.6,f"Prescribed RF = {rf_2050:.2f}",ha="right",va="bottom",fontsize=7.3,color=GOLD,fontweight="semibold")
for sc in SCENARIOS:
    x=energy_2050[sc]
    y=requirements[(requirements.Scenario==sc)&(requirements.Reliability==.90)].f_required.iloc[0]
    ax.plot(x,y,marker="D",ms=6.2,color=SCENARIO_COLOURS[sc],mec="white",mew=.7,zorder=5)
    ax.plot([x,x],[y,rf_2050],color=SCENARIO_COLOURS[sc],lw=1.0,alpha=.75)
    ax.plot(x,rf_2050,marker="o",ms=4.7,color=GOLD,mec="white",mew=.6,zorder=4)
    offsets = {"AR": (-6, 8), "IP": (-18, 9), "BAU": (-32, 8)}
    dx, dy = offsets[sc]
    ax.annotate(f"{sc}  {y:.1f}", (x, y), xytext=(dx, dy), textcoords="offset points",
                fontsize=7.3, color=SCENARIO_COLOURS[sc], va="bottom", ha="left",
                fontweight="semibold",
                bbox=dict(facecolor="white", edgecolor="none", alpha=0.82, pad=0.8))
ax.set(xlim=(45,315),ylim=(0,35),xlabel="Deterministic 2050 energy use (PJ)",ylabel="Maximum 2050 carbon intensity (g CO₂/MJ)")
panel_heading(ax,"b","Inverse test: reliability frontier","Below a curve, the 90% reduction is attained with at least the stated reliability.")
finish_axis(ax)
ax.legend(frameon=False,loc="upper right",fontsize=7.5)
fig.text(.09,.07,"* NZ cases attain all benchmarks by prescribed zero-carbon endpoint construction.",fontsize=7.0,color="#59636D")

save(fig, 8, "Benchmark_Attainment_and_Reliability")


# Figure 9: Robustness
method_order=[PRIMARY,BOOT3,BOOT5]
method_labels=["Gaussian","3-year block","5-year block"]
method_cols=[BLUE,ACCENT_GREEN,GOLD]
rows=[]
for m in method_order:
    rows.append(results[(results.Method==m)&(results.Scenario=="AR")&(results.Pathway=="RF")].iloc[0])
rob=pd.DataFrame(rows);ypos=np.array([2,1,0])
fig,axs=plt.subplots(1,2,figsize=(7.45,3.72),sharey=True)
fig.subplots_adjust(left=.14,right=.98,bottom=.20,top=.68,wspace=.34)
ax=axs[0]
for y,lab,col,row in zip(ypos,method_labels,method_cols,rob.itertuples()):
    ax.hlines(y,row.p05,row.p95,color=col,lw=3.0,alpha=.78)
    ax.plot(row.median,y,"o",color=col,ms=7,mec="white",mew=.8,zorder=3)
    ax.annotate(f"{row.median:.2f}",(row.median,y),xytext=(0,7),textcoords="offset points",
                ha="center",va="bottom",fontsize=8.0,color=col,fontweight="semibold",
                bbox=dict(fc="white",ec="none",pad=1,alpha=0.9),zorder=4)
ax.axvline(thresholds["90%"],color=DARK_GREEN,ls="--",lw=1.0)
ax.text(thresholds["90%"]+0.03, -0.42, f"90% benchmark ({thresholds['90%']:.3f} Mt)",
        ha="left", va="center", fontsize=6.8, color=DARK_GREEN)
ax.set_xlim(.5,3.05);ax.set_ylim(-0.6,2.6);ax.set_yticks(ypos);ax.set_yticklabels(method_labels);ax.set_xlabel("2050 emissions (Mt CO₂)")
panel_heading(ax,"a","Endpoint distribution","Median point with P05–P95 interval.")
finish_axis(ax,"x")
ax=axs[1]
for y,col,row in zip(ypos,method_cols,rob.itertuples()):
    pct=row.p90*100
    ax.hlines(y,0,pct,color=col,lw=7,alpha=.22)
    ax.plot(pct,y,"o",color=col,ms=7.5,mec="white",mew=.8)
    ax.text(pct+.45,y,f"{pct:.2f}%",va="center",fontsize=8.2,color=col,fontweight="semibold")
ax.set_xlim(0,20.5);ax.set_xlabel("Conditional attainment of ≥90% reduction (%)")
panel_heading(ax,"b","Reliability gap","All three specifications leave attainment well below 50%.")
finish_axis(ax,"x");ax.tick_params(axis="y",left=False,labelleft=False)

save(fig, 9, "Robustness")


# Write manifest.
for entry in manifest:
    entry["sha256_pdf"] = hashlib.sha256((OUT / entry["pdf"]).read_bytes()).hexdigest()
    entry["sha256_png"] = hashlib.sha256((OUT / entry["png"]).read_bytes()).hexdigest()
    entry["sha256_svg"] = hashlib.sha256((OUT / entry["svg"]).read_bytes()).hexdigest()
manifest.sort(key=lambda x: x["figure"])
record = {
    "input_file": LOCK.name,
    "input_sha256": hashlib.sha256(LOCK.read_bytes()).hexdigest(),
    "monte_carlo_rerun": False,
    "random_draws": False,
    "thresholds_Mt": thresholds,
    "sigma_26": sigma_26,
    "figures": manifest,
}
(OUT / "figure_manifest.json").write_text(
    json.dumps(record, indent=2), encoding="utf-8"
)
print(f"Figures 3–9 written to {OUT}")
