# Figure reproduction files

This package reproduces Figures 3–9 and the data panels of Figure 2 for the Australian domestic aviation reliability analysis.

## Contents

- `gen_figures.py` — reproduces Figures 3–9
- `fig2_mid.py`, `fig2_cdf.py` — reproduce the two data panels in Figure 2 (AR–RF simulated emissions; 2050 cumulative probability)
- `data/replication_data.xlsx` — replication data: inputs, calibration, pathways, results and simulation settings (see its README sheet)
- `figures/` — PDF, SVG and 600-dpi PNG files
- `figures/figure_data/` — tabular data exported for the figures
- `figures/figure_manifest.json` — input and output checksums
- `SHA256SUMS` — checksums for every file in this package (`sha256sum -c SHA256SUMS`)

## Requirements

Python 3.9 or later is recommended.

```bash
python -m pip install -r requirements.txt
```

## Run

From the package directory:

```bash
python gen_figures.py
python fig2_mid.py
python fig2_cdf.py
```

The input and output paths can be changed if needed:

```bash
python gen_figures.py --lock data/replication_data.xlsx --output figures
```

The script reads the stored model outputs in the replication workbook. It does not rerun the Monte Carlo simulation or generate new random draws.

Figure 5 uses a common 0–25 Mt CO₂ display range across panels. The upper BAU–CI P95 tail extends beyond the displayed range and is labelled in the figure.
